package com.example.myapplication.core

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object API {
    const val API_KEY = "9b61d3590e8e59ad52ae9c590755c7d9"
    const val BASE_URL = "https://api.themoviedb.org/3/movie/"
    const val BASE_URL_IMAGEN = "https://image.tmbd.org/t/p/w500"
    const val IMAGEN_ANCHO = 330
    const val IMAGEN_ALTO = 330
    const val MAX_CALIFICATION = 10.0




}